# Template::Provider::HTTP

[![Build Status](https://secure.travis-ci.org/evdb/template-provider-http.png?branch=master)](https://travis-ci.org/evdb/template-provider-http)

This module lets you fetch templates from a webserver.

For docs please see [the Template::Provider::HTTP page on search.cpan.org](http://search.cpan.org/dist/Template-Provider-HTTP/lib/Template/Provider/HTTP.pm).

## INSTALLATION

To install you can use the following commands:

    perl Makefile.PL
    make
    make test
    make install


## COPYRIGHT AND LICENCE

Copyright (C) 2006-2012, Edmund von der Burg

This library is free software; you can redistribute it and/or modify
it under the same terms as Perl itself.
